package com.mohomx.admin;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.File;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.provider.MediaStore;
import android.os.Environment;
import android.os.Build;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {

    /* false = الملفات داخل التطبيق (تتحدث عند بناء نسخة جديدة) | true = يفتح الموقع المنشور مباشرة (يتحدث تلقائيًا) */
    private static final boolean USE_LIVE_SITE = false;

    private static final String LIVE_HOST = "mohmx-h.github.io";
    private static final String LIVE_BASE = "https://mohmx-h.github.io/m/";
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_BASE = "https://" + APP_HOST + "/assets/web/";

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileLauncher;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        // اختيار الصور من الجهاز (حقول رفع الملفات في اللوحة)
        fileLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) return;
                    Uri[] uris = WebChromeClient.FileChooserParams.parseResult(
                            result.getResultCode(), result.getData());
                    filePathCallback.onReceiveValue(uris);
                    filePathCallback = null;
                });

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);

        web.addJavascriptInterface(new DownloadBridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    fileLauncher.launch(params.createIntent());
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            // نوافذ confirm() و alert() في اللوحة (تأكيد الحذف وغيره) لا تعمل في WebView بدون هذا
            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("موافق", (d, w) -> result.confirm())
                        .setNegativeButton("إلغاء", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                if (isFinishing()) { result.confirm(); return true; }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("حسنًا", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.confirm())
                        .show();
                return true;
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web.canGoBack()) web.goBack(); else finish();
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            loadPage(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadPage(intent);
    }

    private void loadPage(Intent intent) {
        String page = intent == null ? null : intent.getStringExtra("page");
        if (page == null || !page.matches("[A-Za-z0-9_\\-]+\\.html")) page = "admin.html";
        web.loadUrl((USE_LIVE_SITE ? LIVE_BASE : APP_BASE) + page);
    }

    private boolean handleUrl(Uri u) {
        String host = u.getHost() == null ? "" : u.getHost();
        if (host.equals(APP_HOST)) {
            String p = u.getPath() == null ? "" : u.getPath();
            if (p.startsWith("/assets/web/")) return false;          // صفحة داخل التطبيق
            // روابط مثل ../index.html تخرج من مجلد التطبيق: نفتح الموقع المنشور في المتصفح
            String rest = p.startsWith("/assets/") ? p.substring("/assets/".length()) : "";
            openExternal(Uri.parse(LIVE_BASE + rest));
            return true;
        }
        if (USE_LIVE_SITE && host.equals(LIVE_HOST)) return false;
        openExternal(u);
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
        }
    }

    /* Saves backup files (JSON) coming from the dashboard into the Downloads folder.
       WebView ignores blob/anchor downloads, so the dashboard calls AndroidBridge.saveFile(name, text). */
    private class DownloadBridge {
        @JavascriptInterface
        public boolean saveFile(String name, String text) {
            try {
                if (name == null || text == null || text.length() > 60000000) return false;
                String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!safe.endsWith(".json")) safe = safe + ".json";
                byte[] data = text.getBytes(StandardCharsets.UTF_8);
                final String where;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    v.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return false;
                    try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                        o.write(data);
                    }
                    v.clear();
                    v.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, v, null, null);
                    where = "\u0645\u062c\u0644\u062f \u0627\u0644\u062a\u0646\u0632\u064a\u0644\u0627\u062a (Downloads)";
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) return false;
                    File f = new File(dir, safe);
                    try (FileOutputStream o = new FileOutputStream(f)) {
                        o.write(data);
                    }
                    where = f.getAbsolutePath();
                }
                final String msg = "\u062a\u0645 \u062d\u0641\u0638 \u0627\u0644\u0645\u0644\u0641: " + safe + "\n" + where;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
